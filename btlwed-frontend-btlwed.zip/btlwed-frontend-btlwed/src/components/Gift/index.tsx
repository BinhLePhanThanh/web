import React from 'react';

const GiftPage = () => {
    return <div>GiftPage</div>;
};

export default GiftPage;
